/**
 * Created by shannonwilliams on 11/12/15.
 */
$(document).ready(function() {

    $('input').iCheck();

});
